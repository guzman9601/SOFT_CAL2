/*
 * Parallelepiped test using Junit
 */
package figures;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.mockito.Mockito;



public class ParallelepipedIT {
    
    Rectangle rx = new Rectangle(3,4);
    Rectangle ry = new Rectangle(2,4);
    Rectangle rz = new Rectangle(3,2);
    Parallelepiped p = new Parallelepiped(rx,ry,rz);
    
    public ParallelepipedIT() {
    }
    

    //getSide test
    @Test
    public void testGetSideX() {
        Rectangle expected = rx;
        Rectangle result = p.getSideX();
        assertEquals(expected, result);
    }

    //setSideX test
    @Test
    public void testSetSideX() {
        Rectangle side = rx;       
        p.setSideX(side);
       
    }

    //getSideY test
    @Test
    public void testGetSideY() {
        Rectangle expected = ry;
        Rectangle result = p.getSideY();
        assertEquals(expected, result);
       
    }

    //setSideY test
    @Test
    public void testSetSideY() {
        Rectangle side = ry;
        p.setSideY(side);
      
    }

    //getSideZ test
    @Test
    public void testGetSideZ() {
        Rectangle expected = rz;
        Rectangle result = p.getSideZ();
        assertEquals(expected, result);
       
    }

    //setSideZ test
    @Test
    public void testSetSideZ() {
        Rectangle side = rz;
        p.setSideZ(side);
       
    }

    //surface test
    @Test
    public void testSurface() {
        double expected = 52.0;
        double result = p.surface();
        assertEquals(expected, result, 0.0);
       
    }

    //volume test
    @Test
    public void testVolume() {
        double expected = 48.0;
        double result = p.volume();
        assertEquals(expected, result, 0.0);
        
    }
    @Test
    public void MockitoTestArea(){
        Rectangle rec = Mockito.mock(Rectangle.class);
        Parallelepiped para = Mockito.mock(Parallelepiped.class);
        rec.setBase(2);
        rec.setHigh(2);
        para.setSideX(rec);
        para.setSideY(rec);
        para.setSideZ(rec);
        double result, expectedResult=8;
        Mockito.when(para.volume()).thenReturn(expectedResult);
        result=para.volume();
        assertEquals(expectedResult,result,0.0);
    }
}
