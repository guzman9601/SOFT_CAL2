/*
 * Rectangle test using Junit
 */
package figures;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class RectangleIT {
    
    public RectangleIT() {
    } 
    
    //getBase test 
    @Test
    public void testGetBase() {
        Rectangle r = new Rectangle(4.0,3.0);
        double expected = 4.0;
        double result = r.getBase();
        assertEquals(expected, result, 0.0);
        
    }

    //setBase test
    @Test
    public void testSetBase() {
        double base = 0.0;
        Rectangle r = new Rectangle();
        r.setBase(base);
        
    }

    //getHigh test
    @Test
    public void testGetHigh() {
        Rectangle r = new Rectangle(4.0,3.0);
        double expected = 3.0;
        double result = r.getHigh();
        assertEquals(expected, result, 0.0);
        
    }

    //setHigh test
    @Test
    public void testSetHigh() {
        double high = 0.0;
        Rectangle r = new Rectangle();
        r.setHigh(high);
  
    }

    //area test
    @Test
    public void testArea() {
        Rectangle r = new Rectangle(3.0,4.0);
        double expected = 12.0;
        double result = r.area();
        assertEquals(expected, result, 0.0);
      
    }
    
}
