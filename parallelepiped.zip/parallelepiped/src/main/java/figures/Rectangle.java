/*
 *Rectangle class. All angles in a rectangle are assumed to be
 *straight, so I do not take it into account and do not calculate its high.
 */


package figures;
public class Rectangle {
    
     //Attributes
    private double base;    //Rectangle base length
    private double high;    //Rectangle height length

    //Constructors
    public Rectangle(){
        base=0;
        high=0;
    }
    
    public Rectangle (double base, double high){
        this.base=base;
        this.high=high;
    }
      
    //Get and set methods
    public double getBase(){
        return base;
    }
    
    public void setBase(double base){
        this.base=base;
    }
    
    public double getHigh(){
        return high;
    }
    
    public void setHigh(double high){
        this.high=high;
    }
    //Main methods
    
    /*
    Find rectangle area
    */
    public double area(){
        return base*high;
    }
}
