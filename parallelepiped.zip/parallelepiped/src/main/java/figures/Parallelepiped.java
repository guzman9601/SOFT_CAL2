/*
Parallelepiped class. This class is built from the rectangle class,
which will be the ones that form the different sides of the parallelepiped.
Six sides are necessary to build a parallelepiped, equal from 2 to 2, so
that only 3 rectangle type objects will be passed to define the parallelepiped.
*/
package figures;
public class Parallelepiped {
    
    //Attributes
    private Rectangle sideX;   //Rectangle in the x-plane
    private Rectangle sideY;   //Rectangle in the y-plane
    private Rectangle sideZ;   //Rectangle in the z-plane
    
    //Constructors
    public Parallelepiped(){
        
    }
    
    public Parallelepiped(Rectangle sideX, Rectangle sideY, Rectangle sideZ){
        this.sideX=sideX;
        this.sideY=sideY;
        this.sideZ=sideZ;
    }

   

    
    
    //get and set method
    
    public Rectangle getSideX(){
        return sideX;
    }
    
    public void setSideX(Rectangle side){
        sideX=side;
    }
      public Rectangle getSideY(){
        return sideY;
    }
    
    public void setSideY(Rectangle side){
        sideY=side;
    } 
    
    public Rectangle getSideZ(){
        return sideZ;
    }
    
    public void setSideZ(Rectangle side){
        sideZ=side;
    }
    
    /*
    Method to obtain the surface of the parallelepiped.
    Using rectangle class methods to sum all the surfaces of the 6 sides of the figure.
    */
    public double surface(){
        return 2*sideX.area() + 2*sideY.area() + 2*sideZ.area();
    }
    
    /*
    Method to obtain the volume of the parallelepiped.
    Using rectangle class methods to obtain the base of the parallelepiped and its high.
    */
    public double volume(){
        return sideX.area()*sideY.getHigh();
    }
    
}
